# Creating a Detail View Controller

## Starting Project

Use this project to code along with the [Creating a Detail View Controller](https://developer.apple.com/tutorials/app-dev-training/creating-a-detail-view-controller) tutorial.