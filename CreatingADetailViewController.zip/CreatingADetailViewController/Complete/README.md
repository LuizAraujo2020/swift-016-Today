# Creating a Detail View Controller

## Completed Project

Explore the completed project for the [Creating a Detail View Controller](https://developer.apple.com/tutorials/app-dev-training/creating-a-detail-view-controller) tutorial.